# 📚 XActions Examples

A comprehensive collection of example scripts and use cases for XActions. Each guide includes working code samples, configuration options, and best practices.

> **Author:** nich ([@nichxbt](https://x.com/nichxbt))

---

## 🔍 Scraping

Extract data from X (Twitter) with powerful scraping utilities.

| Example | Description |
|---------|-------------|
| [Profile Scraping](profile-scraping.md) | Extract complete profile data including bio, follower counts, and metadata |
| [Followers Scraping](followers-scraping.md) | Collect a user's complete follower list with detailed profile information |
| [Following Scraping](following-scraping.md) | Extract the full list of accounts a user follows |
| [Tweet Scraping](tweet-scraping.md) | Scrape tweets from any user's timeline with engagement metrics |
| [Search Tweets](search-tweets.md) | Search and collect tweets matching specific keywords or queries |
| [Thread Scraping](thread-scraping.md) | Extract complete Twitter threads with all replies in order |
| [Hashtag Scraping](hashtag-scraping.md) | Collect tweets containing specific hashtags for trend analysis |
| [Media Scraping](media-scraping.md) | Download images and videos from tweets and profiles |
| [Link Scraping](link-scraper.md) | Extract and analyze all URLs shared in tweets |
| [List Members Scraping](list-scraping.md) | Scrape all members from public X lists |
| [Likes Scraping](likes-scraping.md) | Collect a user's liked tweets for engagement analysis |

---

## 🚫 Unfollow

Clean up your following list with intelligent unfollow automation.

| Example | Description |
|---------|-------------|
| [Unfollow Non-Followers](unfollow-non-followers.md) | Automatically unfollow accounts that don't follow you back |
| [Unfollow Everyone](unfollow-everyone.md) | Mass unfollow all accounts with configurable rate limiting |
| [Smart Unfollow](smart-unfollow.md) | Intelligent unfollowing based on activity, engagement, and custom rules |

---

## ➕ Follow

Grow your network with targeted follow automation.

| Example | Description |
|---------|-------------|
| [Keyword Follow](keyword-follow.md) | Auto-follow users who tweet about specific topics or keywords |
| [Follow Engagers](follow-engagers.md) | Follow users who engage with specific tweets or accounts |
| [Follow Target's Followers](follow-target-followers.md) | Follow the followers of competitor or niche accounts |

---

## 💬 Engagement

Automate engagement to boost your presence and visibility.

| Example | Description |
|---------|-------------|
| [Auto-Liker](auto-liker.md) | Automatically like tweets matching your criteria |
| [Auto-Commenter](auto-commenter.md) | Post automated replies and comments with AI-powered responses |

---

## 📊 Monitoring

Track account changes and follower activity in real-time.

| Example | Description |
|---------|-------------|
| [Detect Unfollowers](detect-unfollowers.md) | Get notified when someone unfollows you with detailed reports |
| [New Follower Alerts](new-follower-alerts.md) | Receive instant alerts when you gain new followers |
| [Monitor Any Account](monitor-account.md) | Track any public account for follower changes and activity |

---

## ⚡ Advanced

Power-user features for complex workflows and integrations.

| Example | Description |
|---------|-------------|
| [Multi-Account](multi-account.md) | Manage multiple X accounts from a single configuration |
| [Growth Suite](growth-suite.md) | Combine multiple actions into automated growth workflows |
| [MCP Server (AI Agents)](mcp-server.md) | Integrate XActions with AI agents via Model Context Protocol |

---

## 🚀 Quick Start

```bash
# Install XActions
npm install -g xactions

# Run any example
npx xactions <command> [options]
```

## 📖 More Resources

- [Getting Started Guide](../getting-started.md)
- [CLI Reference](../cli-reference.md)
- [Automation Guide](../automation.md)
- [Monitoring Guide](../monitoring.md)

---

<p align="center">
  <b>Built with ❤️ by <a href="https://x.com/nichxbt">@nichxbt</a></b>
</p>
