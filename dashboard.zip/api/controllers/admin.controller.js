import { 
  createLicense,
  validateLicenseKey,
  revokeLicense,
  listLicenses,
  getLicense,
  TIER_FEATURES,
} from '../services/licensing.js';
import { getStats as getPaymentStats } from '../services/payment-stats.js';
import { 
  getWebhookStatus, 
  testWebhooks, 
  hasWebhooksConfigured 
} from '../services/payment-webhooks.js';

/**
 * Create a new license key
 */
export async function createNewLicense(req, res) {
  try {
    const {
      tier = 'starter',
      customerName,
      customerEmail,
      companyName,
      expiresInDays,
      maxInstances,
      notes,
      paymentId,
      amountPaid,
    } = req.body;

    let expiresAt = null;
    if (expiresInDays) {
      expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + parseInt(expiresInDays));
    }

    const license = await createLicense({
      tier,
      customerName,
      customerEmail,
      companyName,
      expiresAt,
      maxInstances,
      notes,
      paymentId,
      amountPaid,
    });

    res.status(201).json({
      success: true,
      license: {
        key: license.key,
        tier: license.tier,
        customerName: license.customerName,
        customerEmail: license.customerEmail,
        companyName: license.companyName,
        maxUsers: license.maxUsers,
        maxInstances: license.maxInstances,
        whiteLabel: license.whiteLabel,
        customDomain: license.customDomain,
        apiAccess: license.apiAccess,
        expiresAt: license.expiresAt,
        createdAt: license.createdAt,
      },
      message: `License key created: ${license.key}`,
    });
  } catch (error) {
    console.error('Create license error:', error);
    res.status(500).json({ error: 'Failed to create license' });
  }
}

/**
 * List all licenses
 */
export async function getLicenses(req, res) {
  try {
    const { status, tier, limit = 100, offset = 0 } = req.query;

    const result = await listLicenses({
      status,
      tier,
      limit: parseInt(limit),
      offset: parseInt(offset),
    });

    res.json(result);
  } catch (error) {
    console.error('List licenses error:', error);
    res.status(500).json({ error: 'Failed to list licenses' });
  }
}

/**
 * Get specific license details
 */
export async function getLicenseByKey(req, res) {
  try {
    const { key } = req.params;
    const license = await getLicense(key);

    if (!license) {
      return res.status(404).json({ error: 'License not found' });
    }

    res.json({ license });
  } catch (error) {
    console.error('Get license error:', error);
    res.status(500).json({ error: 'Failed to get license' });
  }
}

/**
 * Revoke a license
 */
export async function revokeLicenseByKey(req, res) {
  try {
    const { key } = req.params;
    const { reason } = req.body;

    const license = await revokeLicense(key, reason);

    res.json({
      success: true,
      message: 'License revoked',
      license: {
        key: license.key,
        status: license.status,
      },
    });
  } catch (error) {
    console.error('Revoke license error:', error);
    res.status(500).json({ error: 'Failed to revoke license' });
  }
}

/**
 * Get license tiers
 */
export function getLicenseTiers(req, res) {
  res.json({ tiers: TIER_FEATURES });
}

/**
 * Validate license key
 */
export async function validateLicense(req, res) {
  try {
    const { key } = req.params;
    const result = await validateLicenseKey(key);
    res.json(result);
  } catch (error) {
    console.error('Validate license error:', error);
    res.status(500).json({ error: 'Failed to validate license' });
  }
}

/**
 * Get x402 payment statistics
 */
export function getX402Stats(req, res) {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const stats = getPaymentStats();
  res.json({
    success: true,
    stats,
    generatedAt: new Date().toISOString()
  });
}

/**
 * Get x402 webhook status
 */
export function getX402Webhooks(req, res) {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const status = getWebhookStatus();
  res.json({
    success: true,
    webhooks: status,
    generatedAt: new Date().toISOString()
  });
}

/**
 * Test x402 webhooks
 */
export async function testX402Webhooks(req, res) {
  const adminKey = req.headers['x-admin-key'];
  if (adminKey !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (!hasWebhooksConfigured()) {
    return res.status(400).json({
      success: false,
      error: 'No webhooks configured',
      message: 'Set X402_WEBHOOK_URL, DISCORD_WEBHOOK_URL, or SLACK_WEBHOOK_URL in environment variables'
    });
  }

  try {
    const results = await testWebhooks();
    res.json({
      success: true,
      message: 'Test webhooks sent',
      results,
      generatedAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Webhook test error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to test webhooks',
      message: error.message
    });
  }
}
